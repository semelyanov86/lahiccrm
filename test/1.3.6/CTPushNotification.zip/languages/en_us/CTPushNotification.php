<?php
/*+*******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is vTiger
 * The Modified Code of the Original Code owned by https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
  ***************************************************************************** */
$languageStrings = Array(
	'CTPushNotification' => 'CTMobile Push Notification',
	'SINGLE_CTPushNotification' => 'CTMobile Push Notification',
	'CTPushNotification ID' => 'CTMobile Push Notification ID',

	'LBL_CUSTOM_INFORMATION' => 'Custom Information',
	'LBL_MODULEBLOCK_INFORMATION' => 'ModuleBlock Information',
	
	'LBL_SMS_TEXT' => 'In App notification Message',
	'LBL_RECEPIENTS' => 'In App notification recepients',
	'ModuleFieldLabel' => 'ModuleFieldLabel Text',
);

?>
