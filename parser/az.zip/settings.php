<?php
    $db_host="localhost";
    $db_user="root";
    $db_pass="";
    $db_name="az";
    
    $proxy="";
    $proxyauth="";
    
    $crm_url="http://crm1.lahicsu.az:6931/";
    $crm_login="admin";
    $crm_key="NNPpoDxBXNvotIIM";
?>